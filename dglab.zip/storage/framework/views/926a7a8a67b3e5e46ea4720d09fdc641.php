</main>

<!-- Footer -->
<footer class="site-footer style-2 footer-dark background-blend-luminosity"
    style="background-image: url(images/background/bg1.webp)">



    <!-- Footer Top -->
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-6 col-sm-12 wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="0.8s">
                    <div class="widget widget_about me-2">
                        <h2 class="footer-title">Important Updates <br>Waiting for you</h2>
                        <p>Get our latest and best contents right into your inbox</p>
                        <form class="dzSubscribe style-1" action="../assets/script/mailchimp.php" method="post">
                            <div class="dzSubscribeMsg"></div>
                            <div class="form-group">
                                <div class="input-group mb-0">
                                    <input name="dzEmail" required="required" type="email"
                                        class="form-control form-btn-square" placeholder="Your Email Address">
                                    <div class="input-group-addon">
                                        <button name="submit" value="Submit" type="submit" class="btn btn-sm">
                                            <i class="flaticon-message"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-xl-9 col-sm-12 wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="0.8s">
                    <div class="row">
                        <div class="col-xl-3 col-md-3 col-6">
                            <div class="widget widget_services">
                                <h2 class="footer-title">Our Services </h2>
                                <ul class="list-hover1">
                                    <li><a href="service-detail.html"><span>Emergency Care</span></a></li>
                                    <li><a href="service-detail.html"><span>Operation Theater</span></a></li>
                                    <li><a href="service-detail.html"><span>Medical Checkup</span></a></li>
                                    <li><a href="service-detail.html"><span>Diagnostic Center</span></a></li>
                                    <li><a href="service-detail.html"><span>Outdoor Checkup</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-3 col-6">
                            <div class="widget widget_services">
                                <h2 class="footer-title">Useful Links</h2>
                                <ul class="list-hover1">
                                    <li><a href="javascript:void(0);"><span>Privacy Policy</span></a></li>
                                    <li><a href="javascript:void(0);"><span>Terms & Conditions</span></a></li>
                                    <li><a href="contact-us.html"><span>Contact Us</span></a></li>
                                    <li><a href="blog-grid.html"><span>Latest News</span></a></li>
                                    <li><a href="javascript:void(0);"><span>Our Sitemap</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-3 col-6">
                            <div class="widget widget_services">
                                <h2 class="footer-title">Our Stores</h2>
                                <ul class="list-hover1">
                                    <li><a href="javascript:void(0);"><span>New York</span></a></li>
                                    <li><a href="javascript:void(0);"><span>London SF</span></a></li>
                                    <li><a href="javascript:void(0);"><span>Edinburgh</span></a></li>
                                    <li><a href="javascript:void(0);"><span>Los Angeles</span></a></li>
                                    <li><a href="javascript:void(0);"><span>Las Vegas</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-3 col-6">
                            <div class="widget widget_services">
                                <h2 class="footer-title">Quick Links</h2>
                                <ul class="list-hover1">
                                    <li><a href="about-us.html"><span>About Us</span></a></li>
                                    <li><a href="services.html"><span>Our Services</span></a></li>
                                    <li><a href="team.html"><span>Our Team</span></a></li>
                                    <li><a href="appointment.html"><span>Appointments</span></a></li>
                                    <li><a href="contact-us.html"><span>Contact Us</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Top End -->

    <!-- Footer Top -->
    <div class="footer-middle">
        <div class="container">
            <div class="fm-inner">
                <div class="row g-3 align-items-center">
                    <div class="col-xl-3 col-md-12 col-sm-6 wow fadeInUp" data-wow-delay="0.2s"
                        data-wow-duration="0.8s">
                        <h3 class="title">Get in Touch with us</h3>
                        <p class="text">Lorem Ipsum is simply dummy</p>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="0.8s">
                        <div class="icon-bx-wraper style-1">
                            <div class="icon-bx bg-primary">
                                <span class="icon-cell">
                                    <i class="feather icon-phone"></i>
                                </span>
                            </div>
                            <div class="icon-content">
                                <h5 class="dz-title">Call Us</h5>
                                <p><a href="tel:+11234567890" class="text-body">+1 123 456 7890</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="0.8s">
                        <div class="icon-bx-wraper style-1">
                            <div class="icon-bx bg-primary">
                                <span class="icon-cell">
                                    <i class="feather icon-mail"></i>
                                </span>
                            </div>
                            <div class="icon-content">
                                <h5 class="dz-title">Send us a Mail</h5>
                                <p><a href="mailto:info@example.com" class="text-body">info@example.com</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="0.8s">
                        <div class="icon-bx-wraper style-1">
                            <div class="icon-bx bg-primary">
                                <span class="icon-cell">
                                    <i class="feather icon-clock"></i>
                                </span>
                            </div>
                            <div class="icon-content">
                                <h5 class="dz-title">Opening Time</h5>
                                <p>Mon -Sat: 7:00 - 17:00</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <div class="container">
            <div class="fb-inner">
                <div class="row">
                    <div class="col-lg-6 col-md-12 text-start">
                        <p class="copyright-text">© <span class="current-year">2024</span> All Rights Reserved.
                        </p>
                    </div>
                    <div class="col-lg-6 col-md-12 text-end">
                        <img src="images/card.webp" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Bottom End -->

</footer>
<!-- Footer End -->

<button class="scroltop" type="button"><i class="fas fa-arrow-up"></i></button>

</div>
<!-- JAVASCRIPT FILES ========================================= -->
<script src="../assets/js/global.min.js"></script>
<script src="../assets/vendor/popper/popper.js"></script>
<script src="../assets/vendor/tempus-dominus/js/tempus-dominus.min.js"></script>
<script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="../assets/vendor/imagesloaded/imagesloaded.js"></script>
<script src="../assets/vendor/masonry/isotope.pkgd.min.js"></script>
<script src="../assets/vendor/twentytwenty/js/jquery.event.move.js"></script>
<script src="../assets/vendor/twentytwenty/js/jquery.twentytwenty.js"></script>
<script src="../assets/vendor/wnumb/wNumb.js"></script>
<script src="../assets/vendor/countdown/jquery.countdown.js"></script>
<script src="../assets/js/dz.carousel.js"></script>
<script src="../assets/js/dz.ajax.js"></script>
<script src="../assets/js/custom.js"></script>
</body>

</html><?php /**PATH /home/webappss/laravelprojects/dglab/resources/views/layout/footer.blade.php ENDPATH**/ ?>